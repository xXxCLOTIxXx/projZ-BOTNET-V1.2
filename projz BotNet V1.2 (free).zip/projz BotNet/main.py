import config as cfg
from asyncio import run, create_task, gather
import asyncio
from os import system as s
from colored import fore, style
import projz as lib
from json import load
from threading import Thread
s("cls")
print(fore.BLUE + style.BOLD)
print(cfg.name, cfg.links)


with open("accounts.json", "r") as file:
	accounts = load(file)
	print(fore.GREEN, f"{len(accounts)} accounts loaded", fore.ORANGE_1)

clients = {}
circles = []
gmails = []
circle_chats = []
general_gmail = input("Management account gmail>> ")
general_password = input("Management account password>> ")
message = input("Spam text>> ")

async def join(gmail, password, client, info, chats):
	try:
		await client.join_circle(circle_id=info["circle_id"], social_id=info["social_id"])
		print(fore.GREEN, f"{gmail} joined the circle")
		for i in range(len(chats)):
			await client.join_chat(thread_id=chats[i])
		print(fore.GREEN, f"{gmail} entered all possible chats", fore.ORANGE_1)
		clients[gmail]=client
	except Exception as error:
		print(fore.RED, f"{gmail}:\n",error)

async def start(client, gmail):
	await gather(*[create_task(spam(thread_id=circle_chats[i], gmail=gmail, client=client)) for i in range(len(circle_chats))])



async def login_bots(circleId, socialId,  gmail, password, chats):
	try:
		local_client = lib.ZClient(establish_websocket=True)
		await local_client.login(email=gmail,password=password)
		print(fore.GREEN, f"{gmail} logined successfully",fore.ORANGE_1)
		await join(gmail=gmail, password=password, client=local_client, info={"circle_id": circleId, "social_id": socialId}, chats=chats)
	except Exception as error:
		print(fore.RED, f'[{gmail}]:\n', error)


async def general_login(gmail, password, accounts):
	try:
		client = lib.ZClient(establish_websocket=True)
		await client.login(email=gmail,password=password)
		print(fore.GREEN, "Master account logined successfully", fore.ORANGE_1)

		for num, i in enumerate(await client.get_my_circles(size=100), 1):
			print(f"{num}){i.name}")
			circles.append(i)
		while True:
			try:
				selected = int(input("Select circle>> "))
				circleId = circles[selected - 1].circle_id
				socialId = circles[selected - 1].social_id
				try:
					for chats in await client.get_circle_chats(circle_id=circleId, social_id=socialId, size=100):
						circle_chats.append(chats.thread_id)
				except Exception as error:
					print(fore.RED, error, cfg.finish); exit()
				break
			except ValueError:
				print("Please enter a number")
			except IndexError:
				print("Number not found")
			except Exception as error:
				print(fore.RED, error, fore.ORANGE_1)
		await gather(*[create_task(login_bots(circleId=circleId, socialId=socialId,  gmail=accounts[i]["email"], password=accounts[i]["password"], chats=circle_chats)) for i in range(len(accounts))])
	except Exception as error:
		print(fore.RED, error, cfg.finish); exit()


async def spam(thread_id, gmail, client):
	try:
		await client.send_message(thread_id=thread_id, content=message)
	except Exception as error:
		print(f"\n{gmail}:\n", fore.RED, error, fore.ORANGE_1)


async def main():
	await general_login(gmail=general_gmail, password=general_password, accounts=accounts)
	if len(clients)<2:
		print(fore.RED, f"Too few accounts that can spam (you have {len(clients)}, you need at least 2)", cfg.finish); exit()
	for f in clients.keys():
		gmails.append(f)
	print(fore.GREEN, f"Let's start spamming :>", fore.ORANGE_1)
	while True:
		try:
			await gather(*[create_task(start(client=clients[gmails[i]], gmail=gmails[i])) for i in range(len(clients))])
		except Exception as error:
			print(fore.RED, error)
			break
	print(cfg.finish)


if __name__ == "__main__":
	run(main())